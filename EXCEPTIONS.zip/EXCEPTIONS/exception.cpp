#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom Exception: Something went wrong!";
    }
};

bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    // TODO: Throw any standard exception
    throw std::runtime_error("Standard exception thrown in do_even_more_custom_application_logic()");
    return true;
}

void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        do_even_more_custom_application_logic();
    }
    catch (const std::exception& e) {
        // Catch std::exception and display the message
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    // TODO: Throw an exception to deal with divide by zero errors using
    // a standard C++ defined exception
    if (den == 0) {
        throw std::overflow_error("Divide by zero exception");
    }
    return num / den;
}

void do_division() noexcept {
    // TODO: create an exception handler to capture ONLY the exception thrown
    // by divide.
    float numerator = 10.0f;
    float denominator = 0;
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::overflow_error& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
}

int main() {
    std::cout << "Exceptions Tests!" << std::endl;
    try {
        do_custom_application_logic();
        do_division();
        throw CustomException();
    }
    catch (const CustomException& e) {
        std::cerr << "Custom Exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Standard exception caught: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Unhandled exception caught." << std::endl;
    }
    return 0;
}
