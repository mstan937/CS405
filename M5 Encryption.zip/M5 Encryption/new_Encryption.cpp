#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <ctime>

// TODO: Implement XOR-based encryption/decryption
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();
    assert(key_length > 0 && source_length > 0);

    std::string output = source;
    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR each character with the corresponding key character (cycling through the key)
        output[i] = source[i] ^ key[i % key_length];
    }
    return output;
}

// TODO: Implement reading data from a file into a string
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return "";
    }
    std::stringstream buffer;
    buffer << file.rdbuf(); // Read entire file into a stringstream
    return buffer.str();
}

// TODO: Implement saving data to a file with the specified format
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file for writing: " << filename << std::endl;
        return;
    }
    
    // Get current timestamp in yyyy-mm-dd format
    time_t now = time(nullptr);
    tm* local_time = localtime(&now);
    char timestamp[11];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d", local_time);
    
    // Write data in the required format
    file << "Sam Student" << "\n";
    file << timestamp << "\n";
    file << key << "\n";
    file << data << "\n";
}

// TODO: Implement main function to integrate file handling and encryption
int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    std::string filename = "inputdatafile.txt";
    std::string encrypted_filename = "encrypted_data.txt";
    std::string decrypted_filename = "decrypted_data.txt";
    std::string key = "securekey";  // Example key

    // Read the original file
    std::string original_data = read_file(filename);
    if (original_data.empty()) {
        std::cerr << "Failed to read input file." << std::endl;
        return 1;
    }

    // Encrypt data
    std::string encrypted_data = encrypt_decrypt(original_data, key);
    
    // Save encrypted data to file
    save_data_file(encrypted_filename, "Sam Student", key, encrypted_data);

    // Read encrypted file
    std::string encrypted_readback = read_file(encrypted_filename);
    if (encrypted_readback.empty()) {
        std::cerr << "Failed to read encrypted file." << std::endl;
        return 1;
    }

    // Decrypt data
    std::string decrypted_data = encrypt_decrypt(encrypted_readback, key);

    // Save decrypted data to file
    save_data_file(decrypted_filename, "Sam Student", key, decrypted_data);

    std::cout << "Encryption and decryption process completed successfully!" << std::endl;

    return 0;
}
