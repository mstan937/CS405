#include <iostream>
#include <limits> // For input validation
#include <cstring> // For safer string handling functions

int main() {
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account number must remain a constant and directly before the input variable
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";
    std::cin.width(sizeof(user_input)); // Limits input size to prevent overflow
    std::cin >> user_input;

    // Clear any remaining input in the buffer to prevent unwanted behavior
    if (!std::cin) {
        std::cin.clear(); // Reset error state
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Input was too long and has been truncated." << std::endl;
    }
    
    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
    
    return 0;
}
