#include "gtest/gtest.h"
#include <stdexcept>
#include <vector>
#include <string>

// Define the divide function
double divide(double a, double b) {
    if (b == 0) {
        throw std::runtime_error("Division by zero");
    }
    return a / b;
}

// Define CustomException class
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom exception occurred";
    }
};

// Global test environment setup
class Environment : public ::testing::Environment {
public:
    ~Environment() override {}
    void SetUp() override {
        srand(time(nullptr));
    }
    void TearDown() override {}
};

// Test class for shared data between tests
class CollectionTest : public ::testing::Test {
protected:
    void SetUp() override {}
    void TearDown() override {}
};

// Positive test cases
TEST(CollectionTest, EnsureAdditionWorks) {
    EXPECT_EQ(1 + 1, 2);
}

TEST(CollectionTest, EnsureMultiplicationWorks) {
    EXPECT_EQ(3 * 3, 9);
}

TEST(CollectionTest, EnsureStringComparison) {
    std::string str1 = "test";
    std::string str2 = "test";
    EXPECT_EQ(str1, str2);
}

// Negative test cases
TEST(CollectionTest, DivideByZeroThrowsException) {
    EXPECT_THROW({ divide(5, 0); }, std::runtime_error);
}

TEST(CollectionTest, InvalidIndexThrowsException) {
    std::vector<int> vec = {1, 2, 3};
    EXPECT_THROW({ int val = vec.at(5); }, std::out_of_range);
}

// Additional test cases
TEST(CollectionTest, EnsureSubtractionWorks) {
    EXPECT_EQ(10 - 4, 6);
}

TEST(CollectionTest, EnsureDivisionWorks) {
    EXPECT_EQ(10 / 2, 5);
}

TEST(CollectionTest, EnsureModuloWorks) {
    EXPECT_EQ(10 % 3, 1);
}

TEST(CollectionTest, EnsureVectorSizeIsCorrect) {
    std::vector<int> vec = {1, 2, 3};
    EXPECT_EQ(vec.size(), 3);
}

TEST(CollectionTest, EnsureStringConcatenation) {
    std::string str = "Hello " + std::string("World");
    EXPECT_EQ(str, "Hello World");
}

// Custom test cases
TEST(CollectionTest, EnsureCustomExceptionIsThrown) {
    EXPECT_THROW({ throw CustomException(); }, CustomException);
}

TEST(CollectionTest, EnsureFloatingPointComparison) {
    EXPECT_NEAR(0.1 + 0.2, 0.3, 0.0001);
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
